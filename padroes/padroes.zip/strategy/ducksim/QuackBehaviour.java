package padroes.strategy.ducksim;

public interface QuackBehaviour {
	
	public void quack();

}
