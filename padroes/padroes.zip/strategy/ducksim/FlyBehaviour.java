package padroes.strategy.ducksim;

public interface FlyBehaviour {
	
	public void fly();

}
