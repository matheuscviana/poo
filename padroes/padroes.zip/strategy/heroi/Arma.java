package padroes.strategy.heroi;

public interface Arma {
	public void atacar();
}
