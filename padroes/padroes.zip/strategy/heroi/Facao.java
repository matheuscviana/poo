package padroes.strategy.heroi;

public class Facao implements Arma {

	@Override
	public void atacar() {
		System.out.println("Corta com facao SLASH!!!!!!!!");
	}

}