package padroes.strategy.heroi;

public class Trabuco implements Arma {

	@Override
	public void atacar() {
		System.out.println("Atira com trabuco KABUM!!!!!!!!");
	}

}
