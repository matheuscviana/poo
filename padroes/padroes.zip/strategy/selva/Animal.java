package padroes.strategy.selva;

public abstract class Animal {

}
