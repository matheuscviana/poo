package padroes.strategy.selva;

public interface Estrategia {
	
	public void acaoInicial();
	
	public void acaoFinal();

}
