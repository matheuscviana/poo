package padroes.strategy.selva;

public class Bisao extends Animal {

}
