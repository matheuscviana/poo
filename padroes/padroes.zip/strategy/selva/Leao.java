package padroes.strategy.selva;

public class Leao extends Animal {

}
