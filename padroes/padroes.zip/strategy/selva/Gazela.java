package padroes.strategy.selva;

public class Gazela extends Animal {

}
