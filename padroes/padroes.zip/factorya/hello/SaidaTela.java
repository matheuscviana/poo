package padroes.factorya.hello;

public class SaidaTela implements FormatoSaida {

	@Override
	public void saida() {
		System.out.println("Hello World!");
	}

}
