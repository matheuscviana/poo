package padroes.factorya.hello;

public interface FormatoSaida {
	
	public void saida();

}
