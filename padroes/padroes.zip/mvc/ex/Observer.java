package padroes.mvc.ex;

public interface Observer {
  public void update(int id);
}
