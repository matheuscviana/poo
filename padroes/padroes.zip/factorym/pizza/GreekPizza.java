package padroes.factorym.pizza;

public class GreekPizza implements Pizza {

	@Override
	public void prepare() {
		// TODO Auto-generated method stub

	}

	@Override
	public void bake() {
		// TODO Auto-generated method stub

	}

	@Override
	public void cut() {
		// TODO Auto-generated method stub

	}

	@Override
	public void box() {
		// TODO Auto-generated method stub

	}

}
