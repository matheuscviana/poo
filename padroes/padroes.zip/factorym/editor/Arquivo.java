package padroes.factorym.editor;

public interface Arquivo {
	public abstract void abrir(String nome);
}
