package padroes.factorym.editor2;

public class ImagemBMP extends Imagem {
	
	public void carregar() {
       System.out.println("\nImagem BMP:");
       System.out.println("Carregando imagem BMP...");
       System.out.print("...");
       System.out.print("...");
       System.out.println("");
	}

}
