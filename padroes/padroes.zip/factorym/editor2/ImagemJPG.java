package padroes.factorym.editor2;

public class ImagemJPG extends Imagem {
	
	public void carregar() {
       System.out.println("\nImagem JPG:");
       System.out.println("Carregando imagem JPG...");
       System.out.print("...");
       System.out.print("...");
       System.out.println("");
	}

}
