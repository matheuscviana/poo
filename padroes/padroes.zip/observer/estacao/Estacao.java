package padroes.observer.estacao;

import java.util.Observable;

public class Estacao extends Observable {
	
	private float temperatura;
	private float umidade;
	private float vento;
	
	private static final Estacao INSTANCE = new Estacao();
	
	private Estacao() {
		this.temperatura = 0;
		this.umidade = 0;
		this.vento = 0;
	}
	
	public static Estacao getInstance() {
		return INSTANCE;
	}

	public float getTemperatura() {
		return temperatura;
	}

	public void setTemperatura(float temperatura) {
		this.temperatura = temperatura;
		setChanged();
		notifyObservers();
	}

	public float getUmidade() {
		return umidade;
	}

	public void setUmidade(float umidade) {
		this.umidade = umidade;
		setChanged();
		notifyObservers();
	}

	public float getVento() {
		return vento;
	}

	public void setVento(float vento) {
		this.vento = vento;
		setChanged();
		notifyObservers();
	}		

}
