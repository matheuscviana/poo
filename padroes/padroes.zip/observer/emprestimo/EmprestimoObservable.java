package padroes.observer.emprestimo;

import java.util.Observable;

public class EmprestimoObservable extends Observable {
	
	private String banco;
	private String tipo;
	private float taxa;	

	public EmprestimoObservable() {
		this.banco = "";
		this.tipo = "";
		this.taxa = 0;
	}

	public EmprestimoObservable(String banco, String tipo, float taxa) {
		this.banco = banco;
		this.tipo = tipo;
		this.taxa = taxa;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
		setChanged();
		notifyObservers();
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
		setChanged();
		notifyObservers();
	}

	public float getTaxa() {
		return taxa;
	}

	public void setTaxa(float taxa) {
		this.taxa = taxa;
        setChanged();
		notifyObservers();
	}
	
	
	

}
