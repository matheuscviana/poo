package padroes.observer.emprestimo;

import java.util.Observable;
import java.util.Observer;

public class InternetObserver implements Observer {
	
	private String nome;
	
	public InternetObserver(String nome) {
		this.nome = nome;
	}

	@Override
	public void update(Observable arg0, Object arg1) {
		EmprestimoObservable e = (EmprestimoObservable) arg0;
		System.out.println("Banco:" + e.getBanco() );
		System.out.println("Tipo:" + e.getTipo() );
		System.out.println("Taxa:" + e.getTaxa() );
			
	}

}
