package padroes.observer.emprestimo;

public class MainObservable {

	public static void main(String[] args) {

		EmprestimoObservable e = new EmprestimoObservable();
		
		e.addObserver(new InternetObserver("O GLOBO"));
		
		e.setBanco("ITAU");
		e.setTipo("TAXA DE JUROS");
		e.setTaxa(9);

	}

}
