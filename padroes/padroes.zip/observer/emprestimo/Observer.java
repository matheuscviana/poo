package padroes.observer.emprestimo;

public interface Observer {
	
	public void update(float taxa);

}
